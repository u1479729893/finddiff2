# 找茬悬浮助手（Android · Kotlin）

**不用截图、不用裁图**：装好之后屏幕角落出现一个「找」字浮钮，切到游戏里点一下，App 直接抓当前屏幕、自动认出上下两幅画面、把不同之处用红框标回游戏原位置。所有计算都在手机本地完成，**不联网、不上传任何画面**。

---

## 一、先说清楚能做什么、不能做什么

| 能做 | 不能做 |
|---|---|
| 悬浮窗盖在游戏上，点一下就出结果 | 凭空从游戏里「唤起」App（Android 必须先在本 App 里授权一次） |
| 自动定位上下两幅画，标出差异 | 读取别的 App 的私有画面数据（只能读屏幕合成后的像素） |
| 一次授权后可反复抓帧（可开每 3 秒自动刷新） | 绕过系统的录屏确认弹窗（Android 14+ 每次「启动」都要点一次） |
| 只用原生 API，零第三方依赖 | 抓取设了 `FLAG_SECURE` 的游戏（会黑屏，系统限制） |

网页做不到这件事：浏览器读不到其他 App 的画面、也不能盖在别的 App 上面，所以必须是原生 App。

> ⚠️ **交付形态说明**：当前环境没有 Android SDK / Kotlin 编译器，无法直接产出可安装的 APK。这里交付的是**完整可编译的源码工程**，外加一个用 Python 复刻同一算法的离线验证脚本（已用你那张截图跑通 17/17）。 APK 需要在 Android Studio 里点一次 Build，步骤见第三节。

---

## 二、工程结构

```
FindDiffOverlay/
├── settings.gradle / build.gradle / gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── app/
│   ├── build.gradle                       # 零第三方依赖，只用 Android 框架 API
│   └── src/main/
│       ├── AndroidManifest.xml             # 悬浮窗 / 前台服务 / mediaProjection 权限
│       ├── java/com/yuanbao/finddiff/
│       │   ├── MainActivity.kt            # 权限引导、录屏授权、启动/停止服务
│       │   ├── CaptureService.kt          # 前台服务 + MediaProjection + ImageReader 抓帧
│       │   ├── OverlayController.kt       # 可拖动浮钮 + 不拦截触摸的红框覆盖层
│       │   └── DiffEngine.kt              # 纯算法：认画面 → 差分 → 连通域 → 过滤 → 框
│       └── res/                           # 布局、字符串、图标
└── tools/
    └── verify_engine.py                   # 与 DiffEngine.kt 一一对应的离线回归脚本
```

---

## 三、构建安装（约 3 分钟）

1. 用 **Android Studio（Ladybug 或更新版本）** 打开 `FindDiffOverlay/` 根目录
2. 首次打开时 Android Studio 会自动补齐 Gradle Wrapper（本仓库只放了 `gradle-wrapper.properties`，没有二进制 jar），等它同步完
3. 手机开 USB 调试，点 **Run ▶**，或菜单 `Build → Build Bundle(s)/APK(s) → Build APK(s)`
4. 命令行方式（已装 Android SDK + JDK 17）：
   ```bash
   cd FindDiffOverlay
   gradle wrapper          # 若本地已有 gradle，先生成 wrapper jar
   ./gradlew assembleDebug
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

环境要求：`compileSdk 35 / minSdk 26 / targetSdk 35`、AGP 8.5.2、Kotlin 2.0.21、Gradle 8.7、JDK 17。

---

## 四、怎么用

1. 打开 App → 点 **① 开启「显示在其他应用上层」权限**，在系统设置里允许（小米/OPPO/vivo 可能还要额外开「悬浮窗」开关）
2. 回到 App → 点 **② 启动悬浮窗** → 系统弹窗里选 **「整个屏幕」** 并确认
3. 切到找茬游戏 → 屏幕右侧出现紫色「找」浮钮
   - **点一下**：抓当前一帧，1~2 秒后上下两幅画上出现红色编号框
   - **拖动**：可挪到不挡画面的位置
   - **长按**：关闭悬浮窗并停止服务
   - **自动模式**：在 App 里勾选后每 3 秒自动刷新（更费电，建议只在卡关时开）
4. 红框整体偏上/偏下？在 App 的「上下偏移校准」填个像素值再重启一次

抓帧前会**临时隐藏浮层**，避免把自己的浮钮和红框拍进画面造成误报。

---

## 五、算法与实测

`DiffEngine.analyze(frame, w, h)` 流程：

1. **认画面**：把整帧缩到 270 宽，按「非背景色占比 + 行梯度」找出最长的连续画面段；再以段起点/中点为初值，用 90×60 双线性缩略图做两级 SAD 精搜，定位上下两幅画的 y 起点、高度，并自动补偿 1px 高度差
2. **降采样**：两幅画各按 **2/3 BOX 区域平均**缩小，平滑掉 1~3px 的几何错位与 JPEG 噪点
3. **差分**：3 通道均值模糊 → 阈值 33 → 3×3 去噪 → 闭运算 → 8 邻域连通域 → 相邻框合并
4. **过滤**：去掉细长错位条纹；再按框内「平均差异强度 + 强差异像素比例」剔除压缩噪点假框
5. **映射**：框坐标乘 1.5 还原到屏幕像素，画红框时分别加 `panels.ya` / `panels.yb`

**离线回归**（无需手机）：

```bash
pip install Pillow
python3 tools/verify_engine.py /path/to/游戏截图.jpg --expect 17
```

用你这张 1080×2378 的截图实测输出：

```
识别画面: {'ya': 647, 'yb': 1371, 'h': 720, 'hB': 719, 'sad': 6.44}
找到 17 处不同
  ... 17 个框 ...
PASS 期望 17 处，实际 17 处
```

对照上一轮人工核对的 17 处清单，逐个命中、无多余误报。

**想调灵敏度**：改 `app/.../DiffEngine.kt` 里的 `Params`（阈值越大越严格、越小越敏感；`meanMin` / `hotMin` 控制噪点过滤力度），同步改 `tools/verify_engine.py` 顶部同名常量即可用脚本先验证再编译。

---

## 六、已知限制（都是系统层面的，绕不过）

- **Android 14+ 每次「启动」都要重新确认录屏**：token 单次有效。本工程的做法是授权后**只创建一次 VirtualDisplay 并常驻**，之后点浮钮只是从 ImageReader 取最新帧，不重复 `createVirtualDisplay`，因此一次授权内可以无限次抓，符合系统规则。但服务被杀/重启后必须回 App 再点一次「启动」。
- **授权时别选「仅单个应用」**：那样捕获尺寸不是全屏，算法认不出上下两幅画，会明确提示。
- **`FLAG_SECURE` 游戏抓到黑屏**：银行、部分视频/游戏 App 会禁止截屏录屏，这是系统保护。
- **部分国产 ROM 会隐藏悬浮窗**：MIUI / ColorOS / EMUI 需在系统设置里单独放行；系统也可能在键盘、锁屏等场景临时调整浮窗位置。
- **状态栏/刘海可能造成几十像素整体偏移**：用「上下偏移校准」填值即可。
- **动态元素会被当成差异**：倒计时、飘动特效、光标悬停、进度条都会进红框，属正常现象；卡关时看红框最集中的区域即可。
- 游戏若切到**横屏或分屏**，画面段比例变化会导致识别失败，需要重启一次浮窗。

---

## 七、合规提醒

本工具只做「把两张已渲染的画面对比、把差异位置画回屏幕」，不读取游戏内存、不注入点击、不修改游戏数据、不联网。请把它当作卡关时的肉眼辅助，遵守对应游戏的规则，勿用于竞技排名或牟利场景。
