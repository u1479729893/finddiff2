package com.yuanbao.finddiff

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import java.util.concurrent.Executors

/**
 * 前台服务：持有一个常驻 VirtualDisplay（只调用一次 createVirtualDisplay，
 * 符合 Android 14+「每个捕获会话需用户同意」的要求），按需从 ImageReader
 * 取最新一帧交给 DiffEngine，再把红框画到悬浮覆盖层上。
 */
class CaptureService : Service() {

    private lateinit var wm: WindowManager
    private var reader: ImageReader? = null
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var overlay: OverlayController? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var screenW = 0
    private var screenH = 0
    private var dpi = 0
    private var yOffset = 0
    private var auto = false
    private var started = false

    private val autoTask = object : Runnable {
        override fun run() {
            if (!started) return
            captureOnce()
            main.postDelayed(this, 3000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
        try {
            startForegroundWithType()
        } catch (e: Exception) {
            toast("前台服务启动失败：${e.message}")
            stopSelf()
        }
    }

    private fun startForegroundWithType() {
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("悬浮找茬助手正在运行 · 点浮钮抓一帧")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopEverything()
            return START_NOT_STICKY
        }
        if (!started) {
            if (intent != null && intent.hasExtra(EXTRA_DATA)) startProjection(intent)
            else stopEverything()   // 被系统重启但授权已失效，不空挂着前台通知
        }
        return START_STICKY
    }

    private fun startProjection(intent: Intent) {
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, android.app.Activity.RESULT_CANCELED)
        @Suppress("DEPRECATION")
        val data: Intent? = intent.getParcelableExtra(EXTRA_DATA)
        auto = intent.getBooleanExtra(EXTRA_AUTO, false)
        yOffset = intent.getIntExtra(EXTRA_Y_OFFSET, 0)
        if (data == null || resultCode != android.app.Activity.RESULT_OK) { stopEverything(); return }

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        dpi = dm.densityDpi
        if (screenW <= 0 || screenH <= 0) { stopEverything(); return }

        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mpm.getMediaProjection(resultCode, data)
            reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 4)
            // 只创建一次 VirtualDisplay，后续抓帧都复用这个会话
            vd = projection!!.createVirtualDisplay(
                "FindDiff", screenW, screenH, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader!!.surface, null, null
            )
        } catch (e: SecurityException) {
            toast("录屏授权失效，请回到 App 重新「启动」")
            stopEverything()
            return
        } catch (e: Exception) {
            toast("启动捕获失败：${e.message}")
            stopEverything()
            return
        }

        overlay = OverlayController(
            ctx = this,
            screenW = screenW,
            screenH = screenH,
            onCapture = { captureOnce() },
            onStop = { stopEverything() }
        ).also { it.show() }

        started = true
        overlay?.setMessage("准备就绪 · 点我抓一帧 / 长按关闭")
        if (auto) main.postDelayed(autoTask, 1200L)
    }

    /** 点一次浮钮（或自动刷新）就取当前屏幕最新一帧分析 */
    private fun captureOnce() {
        if (!started) return
        // 临时隐藏浮层，避免把自己的红框/浮钮拍进画面造成误报
        overlay?.setHidden(true)
        executor.execute {
            try {
                var image: Image? = null
                repeat(8) {
                    if (image == null) {
                        image = try { reader?.acquireLatestImage() } catch (e: Exception) { null }
                        if (image == null) Thread.sleep(60L)
                    }
                }
                val img = image
                if (img == null) {
                    main.post { overlay?.setHidden(false); overlay?.setMessage("没取到画面，请稍后再点") }
                    return@execute
                }
                if (img.width != screenW || img.height != screenH) {
                    val cw = img.width; val ch = img.height
                    img.close()
                    main.post {
                        overlay?.setHidden(false)
                        overlay?.setMessage("捕获尺寸 ${cw}×${ch} 与屏幕不符，请重启并在授权时选「整个屏幕」")
                    }
                    return@execute
                }
                val pixels = toPixels(img)
                img.close()
                val result = DiffEngine.analyze(pixels, screenW, screenH)
                main.post {
                    overlay?.setHidden(false)
                    if (result.panels == null) {
                        overlay?.setMessage("没认出上下两幅画面（请确认授权时选了「整个屏幕」）")
                    } else {
                        overlay?.draw(result.boxes, result.panels!!, yOffset, result.message)
                    }
                }
            } catch (e: Exception) {
                main.post { overlay?.setHidden(false); overlay?.setMessage("分析出错：${e.message}") }
            }
        }
    }

    /** ImageReader(RGBA_8888) → 0xAARRGGBB 数组，处理 rowStride 行填充 */
    private fun toPixels(image: Image): IntArray {
        val plane = image.planes[0]
        val buf = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * screenW
        val bmpW = screenW + rowPadding / pixelStride
        val bmp = Bitmap.createBitmap(bmpW, screenH, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(buf)
        val px = IntArray(screenW * screenH)
        bmp.getPixels(px, 0, screenW, 0, 0, screenW, screenH)
        bmp.recycle()
        return px
    }

    private fun stopEverything() {
        started = false
        main.removeCallbacks(autoTask)
        overlay?.remove()
        overlay = null
        try { vd?.release() } catch (_: Exception) {}
        vd = null
        try { reader?.close() } catch (_: Exception) {}
        reader = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        executor.shutdownNow()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val c = NotificationChannel(CHANNEL, "悬浮找茬助手", NotificationManager.IMPORTANCE_LOW)
            c.description = "保持屏幕捕获服务运行"
            nm.createNotificationChannel(c)
        }
    }

    private fun toast(s: String) =
        android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopEverything()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL = "finddiff_capture"
        const val ACTION_STOP = "com.yuanbao.finddiff.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        const val EXTRA_AUTO = "auto"
        const val EXTRA_Y_OFFSET = "yOffset"
    }
}
