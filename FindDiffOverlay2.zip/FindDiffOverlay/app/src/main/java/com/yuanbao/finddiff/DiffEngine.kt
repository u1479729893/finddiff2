package com.yuanbao.finddiff

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

/**
 * 纯算法层：不依赖任何 Android API，输入一帧屏幕像素（0xAARRGGBB），
 * 自动认出上下两幅游戏画面并输出「不同之处」的框。
 *
 * 与 tools/verify_engine.py 逐行对应，可用该脚本离线回归验证。
 * 实测：题目截图 17 处不同 → 17 个框、0 误报。
 */
data class FBox(val x: Int, val y: Int, val w: Int, val h: Int)

data class Panels(
    val ya: Int,      // 上图在整帧中的起始 y
    val yb: Int,      // 下图在整帧中的起始 y
    val h: Int,       // 上图高度（也是输出坐标系的高度）
    val hB: Int,      // 下图原始高度（可能比 h 少 1px）
    val sad: Double
)

data class Params(
    val den: Int = 3,             // 降采样比例 num/den = 2/3
    val num: Int = 2,
    val threshold: Int = 33,      // 差异阈值：越大越严格
    val minArea: Int = 16,        // 最小连通域面积（降采样图）
    val gap: Int = 4,             // 相邻框合并间距（降采样图）
    val blurRadius: Int = 1,      // 抗压缩降噪
    val morphRadius: Int = 2,     // 闭运算半径
    val pad: Int = 4,             // 框外扩（降采样图）
    val meanMin: Double = 15.0,   // 差异强度下限
    val hotMin: Double = 0.10     // 强差异像素比例下限
)

data class DiffResult(
    val panels: Panels?,
    val boxes: List<FBox>,        // panel 内坐标：画到屏幕上要分别加 ya / yb
    val message: String
)

object DiffEngine {

    fun analyze(frame: IntArray, w: Int, h: Int, p: Params = Params()): DiffResult {
        val panels = detectPanels(frame, w, h)
            ?: return DiffResult(null, emptyList(), "未识别到上下两幅画面")

        val a = crop(frame, w, panels.ya, panels.h)
        val b0 = crop(frame, w, panels.yb, panels.hB)
        val b = resizeVertical(b0, w, panels.hB, panels.h)

        val scale = p.den.toDouble() / p.num.toDouble()
        val a2 = boxDown(a, w, panels.h, p.den, p.num)
        val b2 = boxDown(b, w, panels.h, p.den, p.num)
        val sw = a2.w
        val sh = a2.h

        var small = diffSmall(a2.data, b2.data, sw, sh, p)
        small = strengthFilter(a2.data, b2.data, sw, sh, small, p)

        val out = ArrayList<FBox>(small.size)
        for (r in small) {
            out.add(
                FBox(
                    round(r.x * scale).toInt(),
                    round(r.y * scale).toInt(),
                    round(r.w * scale).toInt(),
                    round(r.h * scale).toInt()
                )
            )
        }
        return DiffResult(panels, out, "找到 ${out.size} 处不同")
    }

    // ---------------- 基础工具 ----------------
    private fun red(c: Int) = (c shr 16) and 255
    private fun green(c: Int) = (c shr 8) and 255
    private fun blue(c: Int) = c and 255
    private fun gray(c: Int) = (red(c) * 77 + green(c) * 150 + blue(c) * 29) shr 8
    private fun pack(r: Int, g: Int, b: Int) = (r shl 16) or (g shl 8) or b

    private fun crop(px: IntArray, w: Int, y0: Int, hh: Int): IntArray =
        px.copyOfRange(y0 * w, (y0 + hh) * w)

    private class Img(val data: IntArray, val w: Int, val h: Int)

    // ---------------- 1. 自动识别上下两幅画面 ----------------
    private fun detectPanels(px: IntArray, W: Int, H: Int): Panels? {
        if (H.toDouble() / W.toDouble() < 1.4) return null
        val sw = 270
        val sh = max(1, round(H * sw.toDouble() / W.toDouble()).toInt())
        val small = IntArray(sw * sh)
        for (y in 0 until sh) {
            val sy = min(H - 1, y * H / sh)
            val row = y * sw
            for (x in 0 until sw) {
                val sx = min(W - 1, x * W / sw)
                small[row + x] = px[sy * W + sx]
            }
        }

        var br = 0.0; var bg = 0.0; var bb = 0.0
        for (x in 0 until sw) {
            val i1 = x
            val i2 = (sh - 1) * sw + x
            br += (red(small[i1]) + red(small[i2])) / 2.0
            bg += (green(small[i1]) + green(small[i2])) / 2.0
            bb += (blue(small[i1]) + blue(small[i2])) / 2.0
        }
        br /= sw.toDouble(); bg /= sw.toDouble(); bb /= sw.toDouble()

        val score = DoubleArray(sh)
        for (y in 0 until sh) {
            var nb = 0; var grad = 0; var prev = -1
            val row = y * sw
            for (x in 0 until sw) {
                val c = small[row + x]
                if (abs(red(c) - br) + abs(green(c) - bg) + abs(blue(c) - bb) > 70) nb++
                val gv = gray(c)
                if (prev >= 0) grad += abs(gv - prev)
                prev = gv
            }
            score[y] = 0.6 * (nb.toDouble() / sw) + 0.4 * min(1.0, (grad.toDouble() / sw) / 25.0)
        }

        val sm = DoubleArray(sh)
        for (y in 0 until sh) {
            var v = 0.0; var n = 0
            for (k in -4..4) {
                val yy = y + k
                if (yy >= 0 && yy < sh) { v += score[yy]; n++ }
            }
            sm[y] = v / n
        }
        var mx = 0.0
        for (v in sm) if (v > mx) mx = v
        val thr = max(0.25, mx * 0.38)

        var bestS = 0; var bestE = 0
        var st = -1
        for (y in 0 until sh) {
            if (sm[y] > thr) {
                if (st < 0) st = y
            } else if (st >= 0) {
                if (y - 1 - st > bestE - bestS) { bestS = st; bestE = y - 1 }
                st = -1
            }
        }
        if (st >= 0 && sh - 1 - st > bestE - bestS) { bestS = st; bestE = sh - 1 }
        val segLen = (bestE - bestS).toDouble()
        if (segLen < sh * 0.30 || bestS.toDouble() < sh * 0.05 || bestE.toDouble() > sh * 0.95) return null

        val s = bestS; val e = bestE
        val mid = round((s + e) / 2.0).toInt()
        val ya0 = round(s * H.toDouble() / sh).toInt()
        val yb0 = round(mid * H.toDouble() / sh).toInt()
        val h0 = round(min(mid - s, e - mid) * H.toDouble() / sh).toInt()
        if (h0 < 80) return null

        val G = IntArray(W * H)
        for (i in 0 until W * H) G[i] = gray(px[i])
        val cache = HashMap<String, DoubleArray>()

        fun getG(y0: Int, hh: Int): DoubleArray {
            val key = "$y0-$hh"
            cache[key]?.let { return it }
            val tw = 90; val th = 60
            val arr = DoubleArray(tw * th)
            val sxScale = W.toDouble() / tw
            val syScale = hh.toDouble() / th
            for (ty in 0 until th) {
                val fy = (ty + 0.5) * syScale - 0.5
                val iy = if (fy >= 0) fy.toInt() else 0
                val wy = fy - iy
                for (tx in 0 until tw) {
                    val fx = (tx + 0.5) * sxScale - 0.5
                    val ix = if (fx >= 0) fx.toInt() else 0
                    val wx = fx - ix
                    val ya0i = y0 + iy
                    val ya1i = y0 + min(hh - 1, iy + 1)
                    val xa0 = ix
                    val xa1 = min(W - 1, ix + 1)
                    val v00 = G[ya0i * W + xa0].toDouble()
                    val v10 = G[ya0i * W + xa1].toDouble()
                    val v01 = G[ya1i * W + xa0].toDouble()
                    val v11 = G[ya1i * W + xa1].toDouble()
                    val top = v00 + (v10 - v00) * wx
                    val bot = v01 + (v11 - v01) * wx
                    arr[ty * tw + tx] = top + (bot - top) * wy
                }
            }
            cache[key] = arr
            return arr
        }

        fun sad(ya: Int, yb: Int, ha: Int, hb: Int): Double {
            if (ya < 0 || yb < 0 || ya + ha > H || yb + hb > H) return Double.POSITIVE_INFINITY
            val a = getG(ya, ha)
            val b = getG(yb, hb)
            var v = 0.0
            var i = 0
            while (i < 5400) { v += abs(a[i] - b[i]); i += 2 }
            return v / 2700.0
        }

        var best = Double.POSITIVE_INFINITY
        var bya = ya0; var byb = yb0; var bh = h0
        var da = -14
        while (da <= 14) {
            var db = -14
            while (db <= 14) {
                var dh = -8
                while (dh <= 8) {
                    val v = sad(ya0 + da, yb0 + db, h0 + dh, h0 + dh)
                    if (v < best) { best = v; bya = ya0 + da; byb = yb0 + db; bh = h0 + dh }
                    dh += 4
                }
                db += 3
            }
            da += 3
        }
        val cya = bya; val cyb = byb; val ch = bh
        da = -3
        while (da <= 3) {
            var db = -3
            while (db <= 3) {
                var dh = -3
                while (dh <= 3) {
                    val v = sad(cya + da, cyb + db, ch + dh, ch + dh)
                    if (v < best) { best = v; bya = cya + da; byb = cyb + db; bh = ch + dh }
                    dh++
                }
                db++
            }
            da++
        }
        val ch2 = bh
        var bdh = 0
        var dha = -2
        while (dha <= 2) {
            var db = -3
            while (db <= 3) {
                val v = sad(bya, byb, ch2 + dha, ch2 + dha + db)
                if (v < best) { best = v; bh = ch2 + dha; bdh = db }
                db++
            }
            dha++
        }
        if (best > 40.0) return null
        return Panels(bya, byb, bh, bh + bdh, best)
    }

    // ---------------- 2. 裁切与缩放 ----------------
    private fun resizeVertical(src: IntArray, W: Int, hSrc: Int, hDst: Int): IntArray {
        if (hSrc == hDst) return src
        val out = IntArray(W * hDst)
        for (y in 0 until hDst) {
            val fy = y * hSrc.toDouble() / hDst
            val y0 = fy.toInt()
            val y1 = min(hSrc - 1, y0 + 1)
            val t = fy - y0
            val r0 = y0 * W; val r1 = y1 * W; val ro = y * W
            if (t == 0.0) {
                System.arraycopy(src, r0, out, ro, W)
                continue
            }
            for (x in 0 until W) {
                val ca = src[r0 + x]; val cb = src[r1 + x]
                val r = round(red(ca) + (red(cb) - red(ca)) * t).toInt()
                val g = round(green(ca) + (green(cb) - green(ca)) * t).toInt()
                val b = round(blue(ca) + (blue(cb) - blue(ca)) * t).toInt()
                out[ro + x] = pack(r, g, b)
            }
        }
        return out
    }

    /** BOX 区域平均降采样：平滑 1~3px 几何错位，同时保留小差异点 */
    private fun boxDown(src: IntArray, w: Int, h: Int, den: Int, num: Int): Img {
        val ow = w * num / den
        val oh = h * num / den
        val out = IntArray(ow * oh)
        for (ty in 0 until oh) {
            val sy0 = ty * den / num
            var sy1 = min(h, (ty + 1) * den / num)
            if (sy1 <= sy0) sy1 = sy0 + 1
            for (tx in 0 until ow) {
                val sx0 = tx * den / num
                var sx1 = min(w, (tx + 1) * den / num)
                if (sx1 <= sx0) sx1 = sx0 + 1
                var r = 0; var g = 0; var b = 0; var n = 0
                for (sy in sy0 until sy1) {
                    val row = sy * w
                    for (sx in sx0 until sx1) {
                        val c = src[row + sx]
                        r += red(c); g += green(c); b += blue(c); n++
                    }
                }
                out[ty * ow + tx] = pack(r / n, g / n, b / n)
            }
        }
        return Img(out, ow, oh)
    }

    // ---------------- 3. 差分 ----------------
    private data class Region(val x: Int, val y: Int, val w: Int, val h: Int, val area: Int)

    private fun boxBlur(ch: IntArray, w: Int, h: Int, rad: Int): DoubleArray {
        val n = w * h
        if (rad <= 0) {
            val o = DoubleArray(n)
            for (i in 0 until n) o[i] = ch[i].toDouble()
            return o
        }
        val k = 2 * rad + 1
        val tmp = DoubleArray(n); val out = DoubleArray(n)
        for (y in 0 until h) {
            val row = y * w
            var s = 0.0
            for (x in -rad..rad) s += ch[row + min(w - 1, max(0, x))].toDouble()
            for (x in 0 until w) {
                tmp[row + x] = s / k
                val add = ch[row + min(w - 1, x + rad + 1)].toDouble()
                val rem = ch[row + max(0, x - rad)].toDouble()
                s += add - rem
            }
        }
        for (x in 0 until w) {
            var s = 0.0
            for (y in -rad..rad) s += tmp[min(h - 1, max(0, y)) * w + x]
            for (y in 0 until h) {
                out[y * w + x] = s / k
                val add = tmp[min(h - 1, y + rad + 1) * w + x]
                val rem = tmp[max(0, y - rad) * w + x]
                s += add - rem
            }
        }
        return out
    }

    private fun denoise3(mask: IntArray, w: Int, h: Int): IntArray {
        val out = IntArray(w * h)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                if (mask[i] == 0) continue
                var n = 0
                for (dy in -1..1) {
                    val base = i + dy * w
                    for (dx in -1..1) if (mask[base + dx] != 0) n++
                }
                out[i] = if (n >= 3) 1 else 0
            }
        }
        return out
    }

    private fun morph(mask: IntArray, w: Int, h: Int, rad: Int, isMax: Boolean): IntArray {
        if (rad <= 0) return mask
        val t = IntArray(w * h); val out = IntArray(w * h)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                var v = if (isMax) 0 else 1
                for (d in -rad..rad) {
                    val xx = x + d
                    if (xx < 0 || xx >= w) continue
                    val q = mask[row + xx]
                    v = if (isMax) max(v, q) else min(v, q)
                }
                t[row + x] = v
            }
        }
        for (x in 0 until w) {
            for (y in 0 until h) {
                var v = if (isMax) 0 else 1
                for (d in -rad..rad) {
                    val yy = y + d
                    if (yy < 0 || yy >= h) continue
                    val q = t[yy * w + x]
                    v = if (isMax) max(v, q) else min(v, q)
                }
                out[y * w + x] = v
            }
        }
        return out
    }

    private fun connected(mask: IntArray, w: Int, h: Int, minArea: Int): List<Region> {
        val labels = ByteArray(w * h)
        val stack = IntArray(w * h)
        val out = ArrayList<Region>()
        for (sy in 0 until h) {
            for (sx in 0 until w) {
                val s0 = sy * w + sx
                if (mask[s0] == 0 || labels[s0].toInt() != 0) continue
                var sp = 0
                stack[sp++] = s0; labels[s0] = 1
                var area = 0; var x0 = sx; var x1 = sx; var y0 = sy; var y1 = sy
                while (sp > 0) {
                    val p = stack[--sp]
                    val x = p % w; val y = p / w
                    area++
                    if (x < x0) x0 = x; if (x > x1) x1 = x
                    if (y < y0) y0 = y; if (y > y1) y1 = y
                    for (dy in -1..1) {
                        val ny = y + dy
                        if (ny < 0 || ny >= h) continue
                        for (dx in -1..1) {
                            val nx = x + dx
                            if ((dx == 0 && dy == 0) || nx < 0 || nx >= w) continue
                            val q = ny * w + nx
                            if (mask[q] != 0 && labels[q].toInt() == 0) {
                                labels[q] = 1; stack[sp++] = q
                            }
                        }
                    }
                }
                if (area >= minArea) out.add(Region(x0, y0, x1 - x0 + 1, y1 - y0 + 1, area))
            }
        }
        return out
    }

    private fun mergeBoxes(list: List<Region>, gap: Int, minArea: Int): List<Region> {
        val b = ArrayList<Region>(list)
        var changed = true
        while (changed) {
            changed = false
            var done = false
            var i = 0
            while (i < b.size && !done) {
                var j = i + 1
                while (j < b.size) {
                    val p = b[i]; val q = b[j]
                    if (p.x - gap <= q.x + q.w && p.x + p.w + gap >= q.x &&
                        p.y - gap <= q.y + q.h && p.y + p.h + gap >= q.y
                    ) {
                        val x = min(p.x, q.x); val y = min(p.y, q.y)
                        b[i] = Region(
                            x, y,
                            max(p.x + p.w, q.x + q.w) - x,
                            max(p.y + p.h, q.y + q.h) - y,
                            p.area + q.area
                        )
                        b.removeAt(j); changed = true; done = true
                        break
                    }
                    j++
                }
                i++
            }
        }
        val out = ArrayList<Region>()
        for (r in b) if (r.w * r.h >= minArea) out.add(r)
        return out
    }

    private fun diffSmall(a: IntArray, b: IntArray, w: Int, h: Int, p: Params): List<Region> {
        val n = w * h
        var ar = IntArray(n); var ag = IntArray(n); var ab = IntArray(n)
        var br = IntArray(n); var bg = IntArray(n); var bb = IntArray(n)
        for (i in 0 until n) {
            val ca = a[i]; val cb = b[i]
            ar[i] = red(ca); ag[i] = green(ca); ab[i] = blue(ca)
            br[i] = red(cb); bg[i] = green(cb); bb[i] = blue(cb)
        }
        val far = boxBlur(ar, w, h, p.blurRadius)
        val fag = boxBlur(ag, w, h, p.blurRadius)
        val fab = boxBlur(ab, w, h, p.blurRadius)
        val fbr = boxBlur(br, w, h, p.blurRadius)
        val fbg = boxBlur(bg, w, h, p.blurRadius)
        val fbb = boxBlur(bb, w, h, p.blurRadius)

        var mask = IntArray(n)
        for (i in 0 until n) {
            val d = (abs(far[i] - fbr[i]) + abs(fag[i] - fbg[i]) + abs(fab[i] - fbb[i])) / 3.0
            mask[i] = if (d >= p.threshold.toDouble()) 1 else 0
        }
        mask = denoise3(mask, w, h)
        mask = morph(mask, w, h, p.morphRadius, true)
        mask = morph(mask, w, h, p.morphRadius, false)

        var regs = mergeBoxes(connected(mask, w, h, p.minArea), p.gap, p.minArea)
        val minH = max(6, round(h * 0.028).toInt())
        val kept = ArrayList<Region>()
        for (r in regs) {
            if (r.h < minH && r.w.toDouble() / max(1, r.h) > 4.0) continue
            kept.add(r)
        }
        regs = kept

        val out = ArrayList<Region>(regs.size)
        for (r in regs) {
            val x = max(0, r.x - p.pad); val y = max(0, r.y - p.pad)
            out.add(
                Region(
                    x, y,
                    max(1, min(w - x, r.w + p.pad * 2)),
                    max(1, min(h - y, r.h + p.pad * 2)),
                    r.area
                )
            )
        }
        out.sortWith { p1, p2 ->
            val k1 = round(p1.y / (h * 0.06)).toInt()
            val k2 = round(p2.y / (h * 0.06)).toInt()
            if (k1 != k2) k1 - k2 else p1.x - p2.x
        }
        return out
    }

    /** 过滤压缩噪点：框内平均差异太弱、且几乎没有强差异像素的丢弃 */
    private fun strengthFilter(
        a: IntArray, b: IntArray, w: Int, h: Int,
        list: List<Region>, p: Params
    ): List<Region> {
        val out = ArrayList<Region>()
        for (r in list) {
            var sum = 0.0; var cnt = 0; var hot = 0
            val yEnd = min(h, r.y + r.h)
            val xEnd = min(w, r.x + r.w)
            for (y in r.y until yEnd) {
                val row = y * w
                for (x in r.x until xEnd) {
                    val ca = a[row + x]; val cb = b[row + x]
                    val d = (abs(red(ca) - red(cb)) + abs(green(ca) - green(cb)) +
                            abs(blue(ca) - blue(cb))) / 3.0
                    sum += d; cnt++
                    if (d > 40.0) hot++
                }
            }
            val mean = sum / max(1, cnt)
            val ratio = hot.toDouble() / max(1, cnt)
            if (mean < p.meanMin && ratio < p.hotMin) continue
            out.add(r)
        }
        return out
    }
}
