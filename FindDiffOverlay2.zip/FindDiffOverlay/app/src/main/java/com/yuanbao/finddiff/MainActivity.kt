package com.yuanbao.finddiff

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

/**
 * 首次入口：引导两项系统权限，拿到录屏授权后启动前台服务，
 * 之后浮钮常驻，直接切到游戏里用即可。
 */
class MainActivity : Activity() {

    private lateinit var tvStatus: TextView
    private lateinit var btnOverlay: Button
    private lateinit var btnStart: Button
    private lateinit var cbAuto: CheckBox
    private lateinit var etOffset: EditText
    private var projectionManager: android.media.projection.MediaProjectionManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        btnOverlay = findViewById(R.id.btnOverlay)
        btnStart = findViewById(R.id.btnStart)
        cbAuto = findViewById(R.id.cbAuto)
        etOffset = findViewById(R.id.etOffset)

        projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager

        btnOverlay.setOnClickListener {
            val i = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }

        btnStart.setOnClickListener { startCapture() }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            if (!isServiceRunning()) {
                toast("服务本来就没在运行")
                return@setOnClickListener
            }
            val i = Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP)
            startService(i)
            toast("已发送停止指令")
            handler.postDelayed({ refreshStatus() }, 300L)
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        // 部分 ROM 的权限生效有滞后，返回后重新检查
        handler.postDelayed({ refreshStatus() }, 250L)
    }

    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    private fun refreshStatus() {
        val overlayOk = Settings.canDrawOverlays(this)
        val running = isServiceRunning()
        tvStatus.text = buildString {
            append("悬浮窗权限：").append(if (overlayOk) "✅ 已开启" else "❌ 未开启").append('\n')
            append("捕获服务：").append(if (running) "✅ 运行中（切到游戏点浮钮）" else "⭕ 未启动").append('\n')
            append("录屏授权：每次「启动」时需系统确认一次")
        }
        btnStart.isEnabled = overlayOk && !running
    }

    private fun startCapture() {
        if (!Settings.canDrawOverlays(this)) {
            toast("请先开启「显示在其他应用上层」权限")
            return
        }
        val off = etOffset.text.toString().trim().toIntOrNull() ?: 0
        getSharedPreferences("finddiff", MODE_PRIVATE).edit()
            .putBoolean("auto", cbAuto.isChecked)
            .putInt("yOffset", off)
            .apply()
        // Android 14+ 要求：在启动 mediaProjection 前台服务之前先征得用户同意
        @Suppress("DEPRECATION")
        startActivityForResult(projectionManager!!.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return
        if (resultCode != RESULT_OK || data == null) {
            toast("已取消授权")
            return
        }
        val prefs = getSharedPreferences("finddiff", MODE_PRIVATE)
        val i = Intent(this, CaptureService::class.java).apply {
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_DATA, data)
            putExtra(CaptureService.EXTRA_AUTO, prefs.getBoolean("auto", false))
            putExtra(CaptureService.EXTRA_Y_OFFSET, prefs.getInt("yOffset", 0))
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        toast("浮钮已启动，切回游戏即可")
        handler.postDelayed({ refreshStatus() }, 300L)
    }

    private fun isServiceRunning(): Boolean {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        @Suppress("DEPRECATION")
        for (s in am.getRunningServices(Integer.MAX_VALUE)) {
            if (CaptureService::class.java.name == s.service.className) return true
        }
        return false
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    companion object {
        private const val REQ_CAPTURE = 1001
    }
}
