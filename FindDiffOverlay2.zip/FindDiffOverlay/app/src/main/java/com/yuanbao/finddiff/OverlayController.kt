package com.yuanbao.finddiff

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.roundToInt

/** 悬浮层：一个可拖动浮钮 + 一层不拦截触摸的红框覆盖层 */
class OverlayController(
    private val ctx: Context,
    private val screenW: Int,
    private val screenH: Int,
    private val onCapture: () -> Unit,
    private val onStop: () -> Unit
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var resultView: BoxOverlayView? = null
    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    fun show() {
        // 1) 结果层：全屏、不可触摸，让点击穿透到游戏
        val rp = WindowManager.LayoutParams(
            screenW, screenH,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }
        val rv = BoxOverlayView(ctx)
        wm.addView(rv, rp)
        resultView = rv

        // 2) 浮钮：后添加，层级在结果层之上，可拖动/点击/长按
        val d = ctx.resources.displayMetrics.density
        val size = (56 * d).roundToInt()
        val bp = WindowManager.LayoutParams(
            size, size,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenW * 0.82).roundToInt()
            y = (screenH * 0.18).roundToInt()
        }
        val tv = TextView(ctx).apply {
            text = "找"
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.parseColor("#E06366F1"))
                setStroke((2 * d).roundToInt(), Color.parseColor("#FFFFFFFF"))
            }
            elevation = 8f * d
        }
        bindBubbleTouch(tv, bp)
        wm.addView(tv, bp)
        bubble = tv
        bubbleParams = bp
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun bindBubbleTouch(v: View, p: WindowManager.LayoutParams) {
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var downT = 0L; var moved = false
        val longRun = Runnable {
            moved = true                 // 标记后不再触发单击
            onStop()
        }
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = p.x; startY = p.y
                    downT = SystemClock.uptimeMillis()
                    moved = false
                    main.postDelayed(longRun, 650L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (abs(dx) > 8 || abs(dy) > 8) {
                        moved = true
                        main.removeCallbacks(longRun)
                    }
                    if (moved) {
                        p.x = (startX + dx).roundToInt()
                        p.y = (startY + dy).roundToInt()
                        try { wm.updateViewLayout(view, p) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    main.removeCallbacks(longRun)
                    if (e.actionMasked == MotionEvent.ACTION_UP && !moved &&
                        SystemClock.uptimeMillis() - downT < 650L
                    ) onCapture()
                    true
                }
                else -> false
            }
        }
    }

    fun setHidden(hidden: Boolean) {
        val vis = if (hidden) View.INVISIBLE else View.VISIBLE
        resultView?.visibility = vis
        bubble?.visibility = vis
    }

    fun setMessage(msg: String) {
        resultView?.setData(emptyList(), null, 0, msg)
    }

    fun draw(boxes: List<FBox>, panels: Panels, yOffset: Int, msg: String) {
        resultView?.setData(boxes, panels, yOffset, msg)
    }

    fun remove() {
        main.removeCallbacksAndMessages(null)
        bubble?.let { try { wm.removeViewImmediate(it) } catch (_: Exception) {} }
        resultView?.let { try { wm.removeViewImmediate(it) } catch (_: Exception) {} }
        bubble = null; resultView = null
    }

    private fun overlayType(): Int {
        return if (android.os.Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }
}

/** 把红框画回屏幕对应位置：每处差异在上图 +ya、下图 +yb 各画一次 */
private class BoxOverlayView(ctx: Context) : View(ctx) {
    private var boxes: List<FBox> = emptyList()
    private var panels: Panels? = null
    private var yOffset = 0
    private var msg = ""

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#FFEF4444")
        strokeWidth = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 3f, resources.displayMetrics)
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#FFEF4444")
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 12f, resources.displayMetrics)
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val bar = Paint().apply { color = Color.parseColor("#CC0F172A") }
    private val barText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 14f, resources.displayMetrics)
        typeface = Typeface.DEFAULT_BOLD
    }

    fun setData(b: List<FBox>, p: Panels?, off: Int, m: String) {
        boxes = b; panels = p; yOffset = off; msg = m
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val p = panels
        if (p != null) {
            val r = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 9f, resources.displayMetrics)
            for (i in boxes.indices) {
                val o = boxes[i]
                for (base in intArrayOf(p.ya, p.yb)) {
                    val l = o.x.toFloat()
                    val t = o.y.toFloat() + base + yOffset
                    c.drawRoundRect(l, t, l + o.w, t + o.h, r, r, stroke)
                    val cx = l + 15f; val cy = t + 15f
                    c.drawCircle(cx, cy, 14f, fill)
                    c.drawText((i + 1).toString(), cx, cy + 5f, text)
                }
            }
        }
        if (msg.isNotEmpty()) {
            val barH = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 34f, resources.displayMetrics)
            val top = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 28f, resources.displayMetrics)
            c.drawRect(0f, top, width.toFloat(), top + barH, bar)
            c.drawText(msg, 16f, top + barH * 0.68f, barText)
        }
    }
}
