#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DiffEngine.kt 的 1:1 离线复刻，用来在没有 Android 设备的环境下验证算法。

用法：
    python3 verify_engine.py <整张游戏截图路径>
    python3 verify_engine.py <截图路径> --expect 17

依赖：Pillow（pip install Pillow）
本脚本与 Android 工程 DiffEngine.kt 的采样、阈值、形态学、连通域、
合并与强度过滤逻辑逐行对应；跑出的框应与 App 内一致。
"""
import sys
from PIL import Image

# ---- 与 DiffEngine.kt 中 Params 默认值保持一致 ----
DEN, NUM = 3, 2          # 降采样到 2/3，兼顾抗错位与小目标
TH = 33                  # 差异阈值
MIN_AREA = 16            # 连通域最小面积（降采样图）
GAP = 4                  # 合并间距（降采样图）
BLUR_R = 1               # 抗压缩降噪半径
MORPH_R = 2              # 闭运算半径
PAD = 4                  # 框外扩（降采样图）
MEAN_MIN = 15.0          # 差异强度下限
HOT_MIN = 0.10           # 强差异像素比例下限


def load_rgb(path):
    im = Image.open(path).convert('RGB')
    w, h = im.size
    data = im.tobytes()
    px = [0] * (w * h)
    for i in range(w * h):
        j = i * 3
        px[i] = (data[j] << 16) | (data[j + 1] << 8) | data[j + 2]
    return px, w, h


def rgb(c):
    return ((c >> 16) & 255, (c >> 8) & 255, c & 255)


def gray(c):
    r, g, b = rgb(c)
    return (r * 77 + g * 150 + b * 29) >> 8


# ---------------- 1. 自动识别上下两幅画面 ----------------
def detect_panels(px, W, H):
    if H / float(W) < 1.4:
        return None
    sw = 270
    sh = max(1, round(H * sw / float(W)))
    small = [0] * (sw * sh)
    for y in range(sh):
        sy = min(H - 1, y * H // sh)
        row = y * sw
        for x in range(sw):
            sx = min(W - 1, x * W // sw)
            small[row + x] = px[sy * W + sx]

    br = bg = bb = 0.0
    for x in range(sw):
        for idx in (x, (sh - 1) * sw + x):
            r, g, b = rgb(small[idx])
            br += r; bg += g; bb += b
    br /= (2 * sw); bg /= (2 * sw); bb /= (2 * sw)

    score = [0.0] * sh
    for y in range(sh):
        nb = 0; grad = 0; prev = -1
        row = y * sw
        for x in range(sw):
            r, g, b = rgb(small[row + x])
            if abs(r - br) + abs(g - bg) + abs(b - bb) > 70:
                nb += 1
            gv = (r * 77 + g * 150 + b * 29) >> 8
            if prev >= 0:
                grad += abs(gv - prev)
            prev = gv
        score[y] = 0.6 * (nb / float(sw)) + 0.4 * min(1.0, (grad / float(sw)) / 25.0)

    sm = [0.0] * sh
    for y in range(sh):
        v = 0.0; n = 0
        for k in range(-4, 5):
            yy = y + k
            if 0 <= yy < sh:
                v += score[yy]; n += 1
        sm[y] = v / n
    thr = max(0.25, max(sm) * 0.38)

    segs = []
    st = -1
    for y in range(sh):
        if sm[y] > thr:
            if st < 0:
                st = y
        elif st >= 0:
            segs.append((st, y - 1)); st = -1
    if st >= 0:
        segs.append((st, sh - 1))
    if not segs:
        return None
    s, e = max(segs, key=lambda t: t[1] - t[0])
    if e - s < sh * 0.30 or s < sh * 0.05 or e > sh * 0.95:
        return None
    mid = round((s + e) / 2.0)
    ya0 = round(s * H / float(sh))
    yb0 = round(mid * H / float(sh))
    h0 = round(min(mid - s, e - mid) * H / float(sh))
    if h0 < 80:
        return None

    G = [gray(c) for c in px]
    cache = {}

    def get_g(y0, hh):
        key = (y0, hh)
        if key in cache:
            return cache[key]
        tw, th = 90, 60
        arr = [0.0] * (tw * th)
        sx_scale = W / float(tw)
        sy_scale = hh / float(th)
        for ty in range(th):
            fy = (ty + 0.5) * sy_scale - 0.5
            iy = int(fy) if fy >= 0 else 0
            wy = fy - iy
            for tx in range(tw):
                fx = (tx + 0.5) * sx_scale - 0.5
                ix = int(fx) if fx >= 0 else 0
                wx = fx - ix
                ya0 = y0 + iy
                ya1 = y0 + min(hh - 1, iy + 1)
                xa0 = ix
                xa1 = min(W - 1, ix + 1)
                v00 = G[ya0 * W + xa0]; v10 = G[ya0 * W + xa1]
                v01 = G[ya1 * W + xa0]; v11 = G[ya1 * W + xa1]
                top = v00 + (v10 - v00) * wx
                bot = v01 + (v11 - v01) * wx
                arr[ty * tw + tx] = top + (bot - top) * wy
        cache[key] = arr
        return arr

    def sad(ya, yb, ha, hb):
        if ya < 0 or yb < 0 or ya + ha > H or yb + hb > H:
            return float('inf')
        a = get_g(ya, ha); b = get_g(yb, hb)
        v = 0.0
        for i in range(0, 5400, 2):
            v += abs(a[i] - b[i])
        return v / 2700.0

    best = float('inf'); bya = ya0; byb = yb0; bh = h0
    for da in range(-14, 15, 3):
        for db in range(-14, 15, 3):
            for dh in range(-8, 9, 4):
                v = sad(ya0 + da, yb0 + db, h0 + dh, h0 + dh)
                if v < best:
                    best = v; bya = ya0 + da; byb = yb0 + db; bh = h0 + dh
    cya, cyb, ch = bya, byb, bh
    for da in range(-3, 4):
        for db in range(-3, 4):
            for dh in range(-3, 4):
                v = sad(cya + da, cyb + db, ch + dh, ch + dh)
                if v < best:
                    best = v; bya = cya + da; byb = cyb + db; bh = ch + dh
    ch2 = bh; bdh = 0
    for dha in range(-2, 3):
        for db in range(-3, 4):
            v = sad(bya, byb, ch2 + dha, ch2 + dha + db)
            if v < best:
                best = v; bh = ch2 + dha; bdh = db
    if best > 40:
        return None
    return {'ya': bya, 'yb': byb, 'h': bh, 'hB': bh + bdh, 'sad': round(best, 2)}


def crop(px, W, y0, hh):
    return px[y0 * W:(y0 + hh) * W]


def resize_vertical(src, W, hSrc, hDst):
    if hSrc == hDst:
        return src
    out = [0] * (W * hDst)
    for y in range(hDst):
        fy = y * hSrc / float(hDst)
        y0 = int(fy)
        y1 = min(hSrc - 1, y0 + 1)
        t = fy - y0
        r0 = y0 * W; r1 = y1 * W; ro = y * W
        if t == 0:
            out[ro:ro + W] = src[r0:r0 + W]
            continue
        for x in range(W):
            ca = src[r0 + x]; cb = src[r1 + x]
            ra, ga, ba = rgb(ca); rb, gb, bb = rgb(cb)
            r = int(ra + (rb - ra) * t + 0.5)
            g = int(ga + (gb - ga) * t + 0.5)
            b = int(ba + (bb - ba) * t + 0.5)
            out[ro + x] = (r << 16) | (g << 8) | b
    return out


def box_down(src, w, h, den, num):
    """缩小到 num/den，源矩形区域平均（BOX 降采样，抗 1~3px 几何错位）"""
    ow = w * num // den
    oh = h * num // den
    out = [0] * (ow * oh)
    for ty in range(oh):
        sy0 = ty * den // num
        sy1 = min(h, (ty + 1) * den // num)
        if sy1 <= sy0:
            sy1 = sy0 + 1
        for tx in range(ow):
            sx0 = tx * den // num
            sx1 = min(w, (tx + 1) * den // num)
            if sx1 <= sx0:
                sx1 = sx0 + 1
            r = g = b = 0; n = 0
            for sy in range(sy0, sy1):
                row = sy * w
                for sx in range(sx0, sx1):
                    c = src[row + sx]
                    rr, gg, bb = rgb(c)
                    r += rr; g += gg; b += bb; n += 1
            out[ty * ow + tx] = ((r // n) << 16) | ((g // n) << 8) | (b // n)
    return out, ow, oh


# ---------------- 2. 差分 ----------------
def channels(src, n):
    r = [0] * n; g = [0] * n; b = [0] * n
    for i in range(n):
        c = src[i]
        r[i] = (c >> 16) & 255; g[i] = (c >> 8) & 255; b[i] = c & 255
    return r, g, b


def box_blur(ch, w, h, rad):
    if rad <= 0:
        return ch
    k = 2 * rad + 1
    tmp = [0.0] * (w * h); out = [0.0] * (w * h)
    for y in range(h):
        row = y * w
        s = 0.0
        for x in range(-rad, rad + 1):
            s += ch[row + min(w - 1, max(0, x))]
        for x in range(w):
            tmp[row + x] = s / k
            add = ch[row + min(w - 1, x + rad + 1)]
            rem = ch[row + max(0, x - rad)]
            s += add - rem
    for x in range(w):
        s = 0.0
        for y in range(-rad, rad + 1):
            s += tmp[min(h - 1, max(0, y)) * w + x]
        for y in range(h):
            out[y * w + x] = s / k
            add = tmp[min(h - 1, y + rad + 1) * w + x]
            rem = tmp[max(0, y - rad) * w + x]
            s += add - rem
    return out


def denoise3(mask, w, h):
    out = [0] * (w * h)
    for y in range(1, h - 1):
        for x in range(1, w - 1):
            i = y * w + x
            if not mask[i]:
                continue
            n = 0
            for dy in (-1, 0, 1):
                base = i + dy * w
                for dx in (-1, 0, 1):
                    if mask[base + dx]:
                        n += 1
            out[i] = 1 if n >= 3 else 0
    return out


def morph(mask, w, h, rad, is_max):
    if rad <= 0:
        return mask
    t = [0] * (w * h); out = [0] * (w * h)
    for y in range(h):
        row = y * w
        for x in range(w):
            v = 0 if is_max else 1
            for d in range(-rad, rad + 1):
                xx = x + d
                if xx < 0 or xx >= w:
                    continue
                q = mask[row + xx]
                v = max(v, q) if is_max else min(v, q)
            t[row + x] = v
    for x in range(w):
        for y in range(h):
            v = 0 if is_max else 1
            for d in range(-rad, rad + 1):
                yy = y + d
                if yy < 0 or yy >= h:
                    continue
                q = t[yy * w + x]
                v = max(v, q) if is_max else min(v, q)
            out[y * w + x] = v
    return out


def connected(mask, w, h, min_area):
    labels = bytearray(w * h)
    out = []
    for sy in range(h):
        for sx in range(w):
            s0 = sy * w + sx
            if not mask[s0] or labels[s0]:
                continue
            stack = [s0]; labels[s0] = 1
            area = 0; x0 = x1 = sx; y0 = y1 = sy
            while stack:
                p = stack.pop()
                x = p % w; y = p // w
                area += 1
                x0 = min(x0, x); x1 = max(x1, x)
                y0 = min(y0, y); y1 = max(y1, y)
                for dy in (-1, 0, 1):
                    ny = y + dy
                    if ny < 0 or ny >= h:
                        continue
                    for dx in (-1, 0, 1):
                        nx = x + dx
                        if (dx == 0 and dy == 0) or nx < 0 or nx >= w:
                            continue
                        q = ny * w + nx
                        if mask[q] and not labels[q]:
                            labels[q] = 1; stack.append(q)
            if area >= min_area:
                out.append({'x': x0, 'y': y0, 'w': x1 - x0 + 1, 'h': y1 - y0 + 1, 'area': area})
    return out


def merge_boxes(boxes, gap, min_area):
    b = [dict(o) for o in boxes]
    changed = True
    while changed:
        changed = False
        done = False
        for i in range(len(b)):
            if done:
                break
            for j in range(i + 1, len(b)):
                p, q = b[i], b[j]
                if (p['x'] - gap <= q['x'] + q['w'] and p['x'] + p['w'] + gap >= q['x']
                        and p['y'] - gap <= q['y'] + q['h'] and p['y'] + p['h'] + gap >= q['y']):
                    x = min(p['x'], q['x']); y = min(p['y'], q['y'])
                    b[i] = {'x': x, 'y': y,
                            'w': max(p['x'] + p['w'], q['x'] + q['w']) - x,
                            'h': max(p['y'] + p['h'], q['y'] + q['h']) - y,
                            'area': p['area'] + q['area']}
                    b.pop(j); changed = True; done = True
                    break
    return [o for o in b if o['w'] * o['h'] >= min_area]


def diff_small(a, b, w, h):
    n = w * h
    ar, ag, ab = channels(a, n)
    br, bg, bb = channels(b, n)
    ar = box_blur(ar, w, h, BLUR_R); ag = box_blur(ag, w, h, BLUR_R); ab = box_blur(ab, w, h, BLUR_R)
    br = box_blur(br, w, h, BLUR_R); bg = box_blur(bg, w, h, BLUR_R); bb = box_blur(bb, w, h, BLUR_R)
    mask = [0] * n
    for i in range(n):
        d = (abs(ar[i] - br[i]) + abs(ag[i] - bg[i]) + abs(ab[i] - bb[i])) / 3.0
        mask[i] = 1 if d >= TH else 0
    mask = denoise3(mask, w, h)
    mask = morph(mask, w, h, MORPH_R, True)
    mask = morph(mask, w, h, MORPH_R, False)
    boxes = merge_boxes(connected(mask, w, h, MIN_AREA), GAP, MIN_AREA)
    min_h = max(6, round(h * 0.028))
    boxes = [o for o in boxes if not (o['h'] < min_h and o['w'] / float(max(1, o['h'])) > 4)]
    out = []
    for o in boxes:
        x = max(0, o['x'] - PAD); y = max(0, o['y'] - PAD)
        out.append({'x': x, 'y': y,
                    'w': max(1, min(w - x, o['w'] + PAD * 2)),
                    'h': max(1, min(h - y, o['h'] + PAD * 2))})
    out.sort(key=lambda o: (round(o['y'] / (h * 0.06)), o['x']))
    return out


def strength_filter(a, b, w, h, small_boxes, scale):
    """过滤压缩噪点：框内平均差异太弱且几乎没有强差异像素的，丢弃。"""
    n = w * h
    ar, ag, ab = channels(a, n)
    br, bg, bb = channels(b, n)
    out = []
    for o in small_boxes:
        s = 0.0; cnt = 0; hot = 0
        for y in range(o['y'], min(h, o['y'] + o['h'])):
            row = y * w
            for x in range(o['x'], min(w, o['x'] + o['w'])):
                d = (abs(ar[row + x] - br[row + x]) +
                     abs(ag[row + x] - bg[row + x]) +
                     abs(ab[row + x] - bb[row + x])) / 3.0
                s += d; cnt += 1
                if d > 40:
                    hot += 1
        mean = s / max(1, cnt)
        ratio = hot / float(max(1, cnt))
        if mean < MEAN_MIN and ratio < HOT_MIN:
            continue
        out.append(o)
    return out


def analyze(path):
    px, W, H = load_rgb(path)
    p = detect_panels(px, W, H)
    if p is None:
        return None, [], '未识别到上下两幅画面（请确认是整张游戏截图）'
    a = crop(px, W, p['ya'], p['h'])
    b = resize_vertical(crop(px, W, p['yb'], p['hB']), W, p['hB'], p['h'])
    a2, w2, h2 = box_down(a, W, p['h'], DEN, NUM)
    b2, _, _ = box_down(b, W, p['h'], DEN, NUM)
    small = diff_small(a2, b2, w2, h2)
    small = strength_filter(a2, b2, w2, h2, small, DEN / float(NUM))
    scale = DEN / float(NUM)
    boxes = []
    for o in small:
        boxes.append({'x': round(o['x'] * scale), 'y': round(o['y'] * scale),
                      'w': round(o['w'] * scale), 'h': round(o['h'] * scale)})
    return p, boxes, '找到 %d 处不同' % len(boxes)


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('用法: python3 verify_engine.py <整张游戏截图路径> [--expect N]')
        sys.exit(1)
    path = sys.argv[1]
    expect = None
    if '--expect' in sys.argv:
        expect = int(sys.argv[sys.argv.index('--expect') + 1])
    p, boxes, msg = analyze(path)
    print('识别画面:', p)
    print(msg)
    for i, o in enumerate(boxes, 1):
        print('  %2d  (%4d, %4d)  %3d x %3d' % (i, o['x'], o['y'], o['w'], o['h']))
    if expect is not None:
        ok = len(boxes) == expect
        print(('PASS' if ok else 'FAIL') + ' 期望 %d 处，实际 %d 处' % (expect, len(boxes)))
        sys.exit(0 if ok else 2)
